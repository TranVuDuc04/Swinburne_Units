<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="">
            <ul class="navbar-nav">
                <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
                <li class="nav-item"><a href="postjobform.php" class="nav-link">Post Job</a></li>
                <li class="nav-item"><a href="searchjobform.php" class="nav-link">Search Jobs</a></li>
                <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
            </ul>
        </div>
    </nav>
    <div class="container">
    <ul>
        <li>Vu Duc Tran</li>
        <li>s104175614</li>
        <li>104175614@student.swin.edu.au</li>
    </ul>

    <p>
        I declare that this assignment is my individual work. I have not worked collaboratively, nor have I copied from any other student’s work or from any other source.
    </p>
    </div>
</body>
</html>